#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="RectDrawer.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector.Editor.Drawers
{
	using UnityEngine;
	using UnityEditor;
	using Sirenix.OdinInspector.Editor;
	using Sirenix.Utilities.Editor;

	/// <summary>
	/// Rect property drawer.
	/// </summary>
	[OdinDrawer]
	public class RectDrawer : PrimitiveCompositeDrawer<Rect>
	{
		/// <summary>
		/// Draws the property.
		/// </summary>
		protected override void DrawPropertyField(IPropertyValueEntry<Rect> entry, GUIContent label)
		{
			if (label == null)
			{
				var value = entry.SmartValue;
				value.position = SirenixEditorFields.Vector2Field("Position", value.position);
				value.size = SirenixEditorFields.Vector2Field("Size", value.size);
				entry.SmartValue = value;
			}
			else
			{
				var isVisible = entry.Property.Context.Get<bool>(this, "IsVisible", GeneralDrawerConfig.Instance.ExpandFoldoutByDefault);
				isVisible.Value = SirenixEditorGUI.Foldout(isVisible.Value, label);
				if (SirenixEditorGUI.BeginFadeGroup(UniqueDrawerKey.Create(entry, this), isVisible.Value, GeneralDrawerConfig.Instance.GUIFoldoutAnimationDuration))
				{
					var value = entry.SmartValue;
					EditorGUI.indentLevel++;
					value.position = SirenixEditorFields.Vector2Field("Position", value.position);
					value.size = SirenixEditorFields.Vector2Field("Size", value.size);
					EditorGUI.indentLevel--;
					entry.SmartValue = value;
				}
				SirenixEditorGUI.EndFadeGroup();
			}
		}
	}
}
#endif