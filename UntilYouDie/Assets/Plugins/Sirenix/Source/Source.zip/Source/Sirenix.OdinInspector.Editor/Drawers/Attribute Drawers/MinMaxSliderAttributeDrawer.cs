#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using UnityEditor;
    using UnityEngine;

    /// <summary>
    /// Draws Vector2 properties marked with <see cref="MinMaxSliderAttribute"/>.
    /// </summary>
	/// <seealso cref="MinMaxSliderAttribute"/>
	/// <seealso cref="MinValueAttribute"/>
	/// <seealso cref="MaxValueAttribute"/>
	/// <seealso cref="RangeAttribute"/>
	/// <seealso cref="DelayedAttribute"/>
	/// <seealso cref="WrapAttribute"/>
    [OdinDrawer]
    public sealed class MinMaxSliderAttributeDrawer : OdinAttributeDrawer<MinMaxSliderAttribute, Vector2>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(IPropertyValueEntry<Vector2> entry, MinMaxSliderAttribute attribute, GUIContent label)
        {
            Vector2 val = entry.SmartValue;

            if (label == null)
            {
                EditorGUILayout.MinMaxSlider(ref val.x, ref val.y, attribute.MinValue, attribute.MaxValue);
            }
            else
            {
                EditorGUILayout.MinMaxSlider(label, ref val.x, ref val.y, attribute.MinValue, attribute.MaxValue);
            }

            entry.SmartValue = val;
        }
    }
}
#endif