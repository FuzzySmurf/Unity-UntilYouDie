#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="EditorCompilation.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector.Editor
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Reflection.Emit;
    using System.Runtime.CompilerServices;
    using Utilities;
    using Utilities.Editor.CodeGeneration;
    using UnityEditor;
    using UnityEngine;

    /// <summary>
    /// Provides utilities for compiling custom Unity editors into a .dll in the project.
    /// </summary>
    [InitializeOnLoad]
    public static class EditorCompilation
    {
        /// <summary>
        /// <para>An attribute that is put on all automatically generated editors.</para>
        /// <para>Do not use manually.</para>
        /// </summary>
        [AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = false)]
        public class CompiledEditorAttribute : Attribute
        {
            /// <summary>
            /// The drawn type of the editor.
            /// </summary>
            public readonly Type DrawnType;

            /// <summary>
            /// The base editor type of the editor.
            /// </summary>
            public readonly Type EditorType;

            /// <summary>
            /// The name of the drawn type of the editor.
            /// </summary>
            public readonly string DrawnTypeName;

            /// <summary>
            /// The name of the base editor type of the editor.
            /// </summary>
            public readonly string EditorTypeName;

            /// <summary>
            /// Initializes a new instance of the <see cref="CompiledEditorAttribute"/> class.
            /// </summary>
            public CompiledEditorAttribute(Type drawnType, Type editorType, string drawnTypeName, string editorTypeName)
            {
                this.DrawnType = drawnType;
                this.EditorType = editorType;
                this.DrawnTypeName = drawnTypeName;
                this.EditorTypeName = editorTypeName;
            }
        }

        private static HashSet<string> MissingTypeNames = new HashSet<string>();

        private const string GenerationNamespace = "Sirenix.OdinInspector.GeneratedEditors";
        private const string EditorContainerName = "CompiledEditorContainer";

        private const string InspectorAttributesCode = @"
    [CompilerGenerated]
    [CustomEditor(typeof({DrawnType}), false, isFallback = false)]";

        private const string InspectorClassCode = @"
    public sealed class {EditorNamePrefix}_Editor : {BaseEditorType}
    {
    }";

        private const string DrawnTypeKey = "{DrawnType}";
        private const string BaseEditorTypeKey = "{BaseEditorType}";
        private const string EditorNamePrefixKey = "{EditorNamePrefix}";

        static EditorCompilation()
        {
            OverrideUnityTypeResolutionForMissingEditors();

            Assembly assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(ass => ass.GetName().Name == SirenixAssetPaths.OdinGeneratedEditorsAssemblyName);

            if (assembly != null)
            {
                Type type = assembly.GetType(GenerationNamespace + "." + EditorContainerName);

                if (type != null)
                {
                    bool anyMissing = false;

                    foreach (CompiledEditorAttribute attr in type.GetAttributes<CompiledEditorAttribute>())
                    {
                        if (attr.DrawnType == null)
                        {
                            if (InspectorConfig.Instance.AutoRecompileOnChangesDetected)
                            {
                                //Debug.LogWarning("The type " + attr.DrawnTypeName + " has gone missing.");
                                MissingTypeNames.Add(attr.DrawnTypeName);
                            }

                            anyMissing = true;
                        }

                        if (attr.EditorType == null)
                        {
                            if (InspectorConfig.Instance.AutoRecompileOnChangesDetected)
                            {
                                //Debug.LogWarning("The type " + attr.EditorTypeName + " has gone missing.");
                                MissingTypeNames.Add(attr.DrawnTypeName);
                            }

                            anyMissing = true;
                        }
                    }

                    if (anyMissing)
                    {
                        EditorApplication.update += RecompileAsSoonAsPossibleForMissingTypes;
                    }
                    else
                    {
                        EditorApplication.update += RecompileAsSoonAsPossibleIfEditorsChanged;
                    }
                }
            }
            else
            {
                EditorApplication.update += RecompileAsSoonAsPossibleIfAnyEditorsDefined;
            }
        }

        private static void OverrideUnityTypeResolutionForMissingEditors()
        {
            // Unity will sometimes log a bunch of errors when it fails to resolve any inspected editor types that it
            // couldn't find, probably because they changed their names or were deleted.
            //
            // The below code removes this error message, by changing the AppDomain's type resolution logic and
            // emitting meaningless types with the correct names on demand so Unity can feel good about itself.
            //
            // After writing this monstrosity, *we* certainly don't feel very good about ourselves, but it is the only way.

            ModuleBuilder mb = null;
            HashSet<string> createdTypes = new HashSet<string>();
            Type customEditorAttributesType = typeof(CustomEditor).Assembly.GetType("UnityEditor.CustomEditorAttributes");

            if (customEditorAttributesType == null)
            {
                Debug.LogWarning("Odin inspector could not find the internal Unity class 'UnityEditor.CustomEditorAttributes', and so cannot suppress Unity's irrelevant error messages about inspector types going missing. You may see these error messages on recompiles.");
            }
            else
            {
                ResolveEventHandler typeResolver = (object sender, ResolveEventArgs args) =>
                {
                    bool resolve = MissingTypeNames.Contains(args.Name);

                    if (!resolve)
                    {
                        var stackFrames = new System.Diagnostics.StackTrace().GetFrames();

                        for (int i = 0; i < stackFrames.Length; i++)
                        {
                            var method = stackFrames[i].GetMethod();

                            if (method.Name == "Rebuild" && method.DeclaringType == customEditorAttributesType)
                            {
                                resolve = true;
                                break;
                            }
                        }
                    }

                    if (!resolve)
                    {
                        return null;
                    }

                    if (mb == null)
                    {
                        const string name = "Sirenix.OdinInspector.EmittedSuppressErrorTypeResolveAssembly";

                        var ab = AppDomain.CurrentDomain.DefineDynamicAssembly(new AssemblyName() { Name = name }, AssemblyBuilderAccess.Run);
                        mb = ab.DefineDynamicModule(name);
                    }

                    if (!createdTypes.Contains(args.Name))
                    {
                        var typeBuilder = mb.DefineType(args.Name, TypeAttributes.Public, typeof(UnityEngine.Object));
                        typeBuilder.CreateType();

                        createdTypes.Add(args.Name);
                    }

                    return mb.Assembly;
                };

                ResolveEventHandler assemblyResolver = (object sender, ResolveEventArgs args) =>
                {
                    bool resolve = false;

                    var stackFrames = new System.Diagnostics.StackTrace().GetFrames();

                    for (int i = 0; i < stackFrames.Length; i++)
                    {
                        var method = stackFrames[i].GetMethod();

                        if (method.Name == "Rebuild" && method.DeclaringType == customEditorAttributesType)
                        {
                            resolve = true;
                            break;
                        }
                    }

                    if (!resolve)
                    {
                        return null;
                    }

                    // Just return any assembly, who cares, the point is that the type lookup fails
                    // and we go into the type resolve case instead, which we then handle with our
                    // emitted assembly.
                    return typeof(object).Assembly;
                };

                AppDomain.CurrentDomain.TypeResolve += typeResolver;
                AppDomain.CurrentDomain.AssemblyResolve += assemblyResolver;
            }
        }

        private static void RecompileAsSoonAsPossibleIfEditorsChanged()
        {
            if (InspectorConfig.Instance)
            {
                Assembly assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(ass => ass.GetName().Name == SirenixAssetPaths.OdinGeneratedEditorsAssemblyName);
                var type = assembly.GetType(GenerationNamespace + "." + EditorContainerName);
                var editors = InspectorTypeDrawingConfigDrawer.GetEditorsForCompilation();

                var editorAttributes = type.GetAttributes<CompiledEditorAttribute>().ToList();

                if (editors.Length != editorAttributes.Count)
                {
                    //Debug.Log("Types inspected by Odin have changed. You may get some Unity error messages about inspected types being null; this is expected. Triggering a generated editors recompile to automatically fix this. (You can stop this behaviour in Window->Odin Preferences->Editor Types)");
                    TriggerAutomaticRecompile(editors);
                }
                else
                {
                    for (int i = 0; i < editorAttributes.Count; i++)
                    {
                        var attr = editorAttributes[i];

                        if (attr.EditorType != InspectorConfig.Instance.DrawingConfig.GetEditorType(attr.DrawnType))
                        {
                            //Debug.Log("Types inspected by Odin have changed. You may get some Unity error messages about inspected types being null; this is expected. Triggering a generated editors recompile to automatically fix this. (You can stop this behaviour in Window->Odin Preferences->Editor Types)");
                            TriggerAutomaticRecompile(editors);
                            break;
                        }
                    }
                }

                EditorApplication.update -= RecompileAsSoonAsPossibleIfEditorsChanged;
            }
        }

        private static void RecompileAsSoonAsPossibleIfAnyEditorsDefined()
        {
            if (InspectorConfig.Instance)
            {
                RuntimeHelpers.RunClassConstructor(typeof(InspectorTypeDrawingConfigDrawer).TypeHandle);
                var editors = InspectorTypeDrawingConfigDrawer.GetEditorsForCompilation();

                if (editors.Length > 0)
                {
                    //Debug.Log("Generating Odin editor assembly because a pre-existing editor assembly wasn't detected. (You can stop this behaviour in Window->Odin Preferences->Editor Types)");
                    TriggerAutomaticRecompile(editors);
                }

                EditorApplication.update -= RecompileAsSoonAsPossibleIfAnyEditorsDefined;
            }
        }

        private static void RecompileAsSoonAsPossibleForMissingTypes()
        {
            if (InspectorConfig.Instance)
            {
                //Debug.Log("Types inspected by Odin have changed. You may get some Unity error messages about inspected types being null; this is expected. Triggering a generated editors recompile to automatically fix this. (You can stop this behaviour in Window->Odin Preferences->Editor Types)");
                TriggerAutomaticRecompile();
                EditorApplication.update -= RecompileAsSoonAsPossibleForMissingTypes;
            }
        }

        private static void TriggerAutomaticRecompile(TypeDrawerPair[] editors = null)
        {
            if (InspectorConfig.Instance.AutoRecompileOnChangesDetected)
            {
                if (EditorPrefs.HasKey("PREVENT_SIRENIX_FILE_GENERATION"))
                {
                    Debug.LogWarning(SirenixAssetPaths.OdinGeneratedEditorsAssemblyName + " was prevented from beeing generated because the PREVENT_SIRENIX_FILE_GENERATION key was defined in Unity's EditorPrefs.");
                    return;
                }

                CompileEditors(editors ?? InspectorTypeDrawingConfigDrawer.GetEditorsForCompilation());
            }
            else
            {
                //Debug.LogWarning("Types inspected by Odin have changed. You may get some Unity error messages about inspected types being null. To fix this, go to Window->Odin Preferences->Editor Types and recompile editors. (You can enable automatic recompilation in Window->Odin Preferences->Editor Types)");
            }
        }

        /// <summary>
        /// <para>Compiles a given set of editors into a .dll in the assembly. The path to the .dll is determined using <see cref="SirenixAssetPaths.OdinGeneratedEditorsPath"/>.</para>
        /// <para>If editor compilation fails, the generated compilation files will be kept in a randomly named folder in the Temp folder of the current Unity project. The precise path, and compilation errors, will be logged to the console.</para>
        /// </summary>
        public static bool CompileEditors(TypeDrawerPair[] editors)
        {
            if (editors == null)
            {
                throw new ArgumentNullException("editors");
            }

            HashSet<string> duplicateTypeNames = new HashSet<string>();

            // Find duplicates
            {
                HashSet<string> seenNames = new HashSet<string>();

                foreach (var typeDrawerPair in editors)
                {
                    Type drawnType = InspectorTypeDrawingConfig.TypeBinder.BindToType(typeDrawerPair.DrawnTypeName);
                    Type editorType = InspectorTypeDrawingConfig.TypeBinder.BindToType(typeDrawerPair.EditorTypeName);

                    if (drawnType == null || editorType == null)
                    {
                        continue;
                    }

                    if (seenNames.Contains(drawnType.FullName))
                    {
                        duplicateTypeNames.Add(drawnType.FullName);
                        continue;
                    }

                    seenNames.Add(drawnType.FullName);
                }
            }

            using (AssemblyGenerator generator = new AssemblyGenerator())
            {
                generator.DefaultNamespace = GenerationNamespace;
                generator.ReferenceUnityAssemblies = true;
                generator.ReferenceUserScriptAssemblies = true;
                generator.IncludeEditorAssemblies = true;
                generator.IncludeNonPluginUserScriptAssemblies = true;
                generator.IncludeActiveUnityDefines = true;
                generator.KeepFiles = true;
                generator.KeepFilesOnError = true;
                generator.LogErrors = true;

                // Write CompiledEditorContainer class, which ensures that we can check up on when
                // drawn types or base editors are no longer there, and trigger a recompile.
                {
                    CodeWriter writer = generator.CreateCodeWriter(EditorContainerName);

                    writer.RegisterTypeSeen(typeof(CompiledEditorAttribute));

                    foreach (TypeDrawerPair typeDrawerPair in editors)
                    {
                        Type drawnType = InspectorTypeDrawingConfig.TypeBinder.BindToType(typeDrawerPair.DrawnTypeName);
                        Type editorType = InspectorTypeDrawingConfig.TypeBinder.BindToType(typeDrawerPair.EditorTypeName);

                        if (drawnType == null || editorType == null || duplicateTypeNames.Contains(drawnType.FullName))
                        {
                            continue;
                        }

                        generator.AddReferencedAssembly(drawnType.Assembly);
                        generator.AddReferencedAssembly(editorType.Assembly);

                        writer.WriteAttribute(typeof(CompiledEditorAttribute), "typeof(" + drawnType.GetNiceFullName() + "), typeof(" + editorType.GetNiceFullName() + "), \"" + drawnType.GetNiceFullName() + "\", \"" + editorType.GetNiceFullName() + "\"");
                    }

                    writer.BeginType(AccessModifier.Internal, TypeDeclaration.StaticClass, EditorContainerName);
                    writer.EndType();
                }

                // Write drawers
                {
                    CodeWriter writer = generator.CreateCodeWriter("Drawers");

                    writer.RegisterTypeSeen(typeof(CompilerGeneratedAttribute));
                    writer.RegisterTypeSeen(typeof(CustomEditor));

                    foreach (TypeDrawerPair typeDrawerPair in editors)
                    {
                        Type drawnType = InspectorTypeDrawingConfig.TypeBinder.BindToType(typeDrawerPair.DrawnTypeName);
                        Type editorType = InspectorTypeDrawingConfig.TypeBinder.BindToType(typeDrawerPair.EditorTypeName);

                        if (drawnType != null && editorType != null && !drawnType.IsGenericTypeDefinition && InspectorTypeDrawingConfig.UnityInspectorEditorIsValidBase(editorType, drawnType) && !duplicateTypeNames.Contains(drawnType.FullName))
                        {
                            generator.AddReferencedAssembly(drawnType.Assembly);
                            generator.AddReferencedAssembly(editorType.Assembly);

                            writer.PasteChunk(InspectorAttributesCode.Replace(DrawnTypeKey, drawnType.GetNiceFullName()));

                            if (editorType.IsDefined<CanEditMultipleObjects>())
                            {
                                writer.WriteAttribute(typeof(CanEditMultipleObjects));
                            }

                            string editorNamePrefix;

                            if (drawnType.IsGenericType)
                            {
                                editorNamePrefix = drawnType.GetNiceFullName()
                                                            .Replace(" ", "")
                                                            .Replace(",", "_")
                                                            .Replace("<", "_")
                                                            .Replace(">", "");
                            }
                            else
                            {
                                editorNamePrefix = drawnType.GetNiceFullName().Replace('.', '_');
                            }

                            writer.PasteChunk(InspectorClassCode.Replace(EditorNamePrefixKey, editorNamePrefix).Replace(BaseEditorTypeKey, editorType.GetNiceFullName()));
                        }
                    }
                }

                // Give errors for conflicts
                if (duplicateTypeNames.Count > 0 && !InspectorConfig.Instance.DisableTypeNameConflictWarning)
                {
                    Debug.LogWarning("Warning: There were type name collisions during generated editors compilation. The types have been disabled in future editor compiles. Odin is unable to generate editors for any types with conflict names. The following " + duplicateTypeNames.Count + " warnings detail the conflicts in question:");

                    foreach (var typeName in duplicateTypeNames)
                    {
                        var duplicateTypes = editors.Where(n => n.DrawnTypeName != null)
                                                    .Select(n => InspectorTypeDrawingConfig.TypeBinder.BindToType(n.DrawnTypeName))
                                                    .Where(n => n != null && n.FullName == typeName)
                                                    .ToList();

                        foreach (var type in duplicateTypes)
                        {
                            InspectorConfig.Instance.DrawingConfig.SetEditorType(type, null);
                        }

                        string warningMessage =
                            "        " + duplicateTypes.Count + " types with the full name '" + typeName + "' exist in the following " +
                            "assemblies: " + string.Join(", ", duplicateTypes.Select(n => "\"" + n.Assembly.FullName + "\"").ToArray());

                        Debug.LogWarning(warningMessage);
                    }

                    EditorUtility.SetDirty(InspectorConfig.Instance);
                    AssetDatabase.SaveAssets();
                }

                var result = generator.Compile(SirenixAssetPaths.OdinGeneratedEditorsPath);

                if (result)
                {
                    AssetDatabase.Refresh();
                }

                return result;
            }
        }
    }
}
#endif