#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="GameObjectContextMenus.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.Utilities.Editor
{
    using UnityEditor;
    using UnityEngine;

    internal static class GameObjectContextMenus
    {
        [MenuItem("GameObject/MyMenu/Do Something", false, 0)]
        private static void Init()
        {
            Debug.Log("here");
        }
    }
}
#endif