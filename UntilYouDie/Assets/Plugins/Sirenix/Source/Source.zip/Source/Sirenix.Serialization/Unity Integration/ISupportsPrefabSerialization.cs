//-----------------------------------------------------------------------
// <copyright file="ISupportsPrefabSerialization.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.Serialization
{
    /// <summary>
    /// Not yet documented.
    /// </summary>
    public interface ISupportsPrefabSerialization
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        SerializationData SerializationData { get; set; }
    }
}